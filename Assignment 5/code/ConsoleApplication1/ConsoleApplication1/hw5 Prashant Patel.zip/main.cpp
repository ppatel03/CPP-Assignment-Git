///////////////////////////////////////////////////////////////////////////  
// NAME : PRASHANT M PATEL												 //
//																		 //
// FILENAME : main.cpp													 //
//																		 //
// COURSE NUMBER : CIS 554												 //
//																		 //
// DESC   : creates the object of WordFont Class and calls the 			 //
//			appropriate method  to draw the characters in the 		     //
//			screen.														 //
//																		 //
//																		 //
//////////////////////////////////////////////////////////////////////////

#include "WordFont.h";
#include <iostream>
using std::cin;

int main(){
	WordFont wordFont;

	wordFont.takeUserInput();

	cin.get();
	cin.get();
}